<?php

if(!$auth->isAdmin()) { //is not super
	if(!$auth->isUser()) { //is not admin
		 $pageTitle = "Please Login.";
		 $page = "login"; //redirect unauthorized; is artist
		//do user stuff here
		
	}

	else {

		$pageTitle = "Not Authorized.";
		 $page = "block";
		//do public stuff here
	}
}
else {


$edit = (isset($_GET['edit']) ? true : false);
$save = (isset($_GET['save']) ? true : false);
$delete  = (isset($_GET['del']) ? true : false);
$new  = (isset($_GET['new']) ? true : false);

$filename = (isset($_REQUEST['p']) ? addslashes(strip_tags($_REQUEST['p'])) : "default");

if(!$edit && !$save && !$new) {
	$pageTitle = "Content";
}
else {
	$pageTitle = "$filename - Content"; 
}


$dirlist = $dir->read_dir(SITE_PATH."/pages", $recursive='false');

$cnt = 0;
$col = 0;
	$count = count($dirlist);


	$show = 20;
	$pages = ceil($count/$show);

	$limit = (isset($_GET['pg']) ? addslashes($_GET['pg']) : 1);

	$min = ($limit-1) * $show; 
	$max = $limit * $show; 


			$list = "<table width=\"100%\" cellpadding=\"0\" cellspacing=\"10\" border=\"0\">
						<tr>";
		for($i=0;$i < $count;$i++) {
					$filename = substr($dirlist[$i], 0, (strlen($dirlist[$i])-5) );
			
					if($filename != "authorize" && $filename != "graph" && ($cnt <= $max) && ((($i <= $max) && ($i >= $min))|| (($i >= $min) && ($i <= $max)))) {
						if($col == 0) {
										$list .= "<td width=\"50%\" valign=\"top\">
													<p>";
						}
						if (file_exists(SITE_PATH."/images/gnome/$filename.png")) {
							$list .= "<a href=\"pages?p=".
								$filename."&edit&ui&KeepThis=true&TB_iframe=true&height=550&width=900\" class=\"thickbox\">
								<img 
								src=\"$domain/images/gnome/$filename.png								\">
								</img><br>
								<b>$filename</b>
								</a>
								<br>
								";
						}
						else {
							$list .= "<a href=\"pages?p=".
								$filename."&edit&ui&KeepThis=true&TB_iframe=true&height=550&width=900\" class=\"thickbox\">
								<img 
								src=\"$domain/images/gnome/default/text-html.png								\">
								</img><br>
								<b>$filename</b>
								</a>
								<br>
								";
				
						}
							$list .= "	<small>
									<a href=\"javascript:uiConfirm('pages?p=".
$filename."&del', '".$filename."');\">delete</a>
									</small>
									<br>
									<br>
									";
						
						$col++;
						$cnt++;
						
						if($col > 7) {
							$list .= "</p>
									</td>";
							$col = 0;
						}
					}
		}
			$list .= "</tr>
					</table>";

$count=$count-2;
}

?>