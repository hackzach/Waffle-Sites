<?php 


if(!isSuper($id)) { //is not super
	if(!isAdmin($id)) { //is not admin
		if(!isArtist($id)) { //is not artist
			if(!isUser($id)) { //is not logged in
				$pageTitle = "Please Login.";
				$page = "login"; //redirect login; not public
				//is public
				//do public stuff here
			}
			else $page = "block"; //redirect unauthorized; not admin
			//is user
			//do user stuff here
		}
		else $page = "block"; //redirect unauthorized; not super
		//is artist
		//do artist stuff here
		
	}
	else $page = "block"; //redirect unauthorized; not super
	 //is admin
	 //do admin stuff here

}
//is super
//do super stuff here


?>