<?php $pageTitle = "New Page";
/*put code here*/
?>