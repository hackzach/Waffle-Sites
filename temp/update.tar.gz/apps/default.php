<?php $pageTitle = "Default Page Title";
/*put code here*/
?>	