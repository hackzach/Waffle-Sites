<?php

$pageTitle = "Edit Profile";

 if(!auth($id,"1")) 

$page = "login"; 

?>