<?php

$pageTitle = "Home";

if(!auth($id, "1")) {

	$page = "login";

}

$name = addslashes($_REQUEST['name']);
$email = addslashes($_REQEST['email']);
$isprivate = addslashes($_REQUEST['isprivate']);
$status = addslashes($_REQUEST['status']);
$pid = addslashes($_REQUEST['pid']);
$get_fontcolor = addslashes($_REQUEST['fontcolor']);
$get_bgcolor = addslashes($_REQUEST['bgcolor']);
$edit = $_REQUEST['edit'];
$bgcolor = $info['theme_bgcolor'];
$fontcolor = $info['theme_fontcolor'];
$you = $_REQUEST['id'];
$pid = $_REQUEST['pid'];
$stream = $_REQUEST['feed'];


if(isset($_REQUEST['save'])) {
			if(!auth($id,"1")) {
				$page = "login"; //You are not logged in
			}
			//Save updated profile
	if(isset($name) && isset($email) && isset($isprivate) && isset($status) && isset($get_bgcolor) && isset($get_fontcolor)) {
	$result = q("UPDATE users SET 

	name='$name',
	email='$email',
	
 	profile='$isprivate',
	theme_bgcolor='$get_bgcolor',
	theme_fontcolor='$get_fontcolor',
 
 	status='$status'

	WHERE id='$id'");
	echo "<script>window.location='home?id=$id&pid=$pid'</script>";
	}
}

else if(isset($you)) {

			if(isset($edit)) {
		
				if(!isadmin($id)) {
					$page = "block"; //You are not a level 3
				}
				
				else {
					$id = $you; //This is admin edit bio page. Userlevel 3
		

					
				}
			}
			else {
				if(isprivate($you)) {
					$page = "private"; //Profile is set to private
				}
				
				//this is your main page loader.
				$page = "you";
			}

}


else if(isset($stream)) {
		$home = stream("https://graph.facebook.com/me/home?".$access_token);

		$decoded = json_decode($home,true); 
		
}

?>					
<a href="/home?edit">Edit Profile</a> | <a href="/home?feed">View Feed</a>