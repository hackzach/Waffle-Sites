<?php
ob_start();

$pageTitle = "Home";

if(!$auth->isUser()) {

	$page = "login";

}

$name = (isset($_REQUEST['name']) ? addslashes($_REQUEST['name']) : NULL);
$email = (isset($_REQUEST['email']) ? addslashes($_REQUEST['email']) : NULL);
$location = (isset($_REQUEST['location']) ? addslashes($_REQUEST['location']) : NULL);
$hide_email = (isset($_REQUEST['hide_email']) ? addslashes($_REQUEST['hide_email']) : NULL);
$isprivate = (isset($_REQUEST['isprivate']) ? addslashes($_REQUEST['isprivate']) : NULL);
$birthdate = (isset($_REQUEST['birthdate']) ? addslashes($_REQUEST['birthdate']) : NULL);
$gender = (isset($_REQUEST['gender']) ? addslashes($_REQUEST['gender']) : NULL);
$status = (isset($_REQUEST['status']) ? addslashes($_REQUEST['status']) : NULL);
$pic = (isset($_REQUEST['pic']) ? addslashes($_REQUEST['pic']) : NULL);
$get_bgcolor = (isset($_REQUEST['bgcolor']) ? addslashes($_REQUEST['bgcolor']) : NULL);
$get_fontcolor = (isset($_REQUEST['fontcolor']) ? addslashes($_REQUEST['fontcolor']) : NULL);
$get_fontsize = (isset($_REQUEST['fontsize']) ? addslashes($_REQUEST['fontsize']) : NULL);
$get_font = (isset($_REQUEST['font']) ? addslashes($_REQUEST['font']) : NULL);

$bgcolor = $user['theme_bgcolor'];
$fontcolor = $user['theme_fontcolor'];
$fontsize = $user['theme_fontsize'];
$font =     $user['theme_font'];

		if(isset($you)) {
					if(is_numeric($you)) {
						$profile_data = $query->select("users", "*", "WHERE id='".$you."'", $debug);
						
						if(!$profile_data) {
							$profile_data = $query->select("users", "*", "WHERE id='".APP_ID."'", $debug);
						}
					}
					else {
						$profile_data = str_replace("-", " ", $you);
						$profile_data = $query->select("users", "*", "WHERE name='".$profile_data."'", $debug);
						
						if(!$profile_data) {
							$profile_data = $query->select("users", "*", "WHERE id='".APP_ID."'", $debug);
						}
						
					}
					if($auth->isPrivate($profile_data['id']) && !$auth->isAdmin()) {
						$page = "private"; //Profile is set to private
						$pageTitle = "Private Page.";
					}
					else {
						//this is your main page loader.
						$page = "home/you";
						$pageTitle = $profile_data['status'];
					}
		}




	if(isset($_REQUEST['save'])) {
			if(!$auth->isUser()) {
				$page = "login"; //You are not logged in
			}
			//Save updated profile
	if(isset($name) && isset($isprivate)) {
	$result = $query->update("users", "
	name='$name',
	email='$email',
	location='$location',
	hide_email='$hide_email',
	profile_pic='$pic',
 	profile='$isprivate',
	birthdate='$birthdate',
	gender='$gender',
	theme_bgcolor='$get_bgcolor',
	theme_fontcolor='$get_fontcolor',
 	theme_fontsize='$get_fontsize',
	theme_font='$get_font',
 	status='$status'", 

	"WHERE id='".($auth->isAdmin() ? (isset($profile_data['id']) ? $profile_data['id'] : ID) : ID)."'"); 

	ob_flush();
		header("Location: ".$domain."/i/".(isset($profile_data['id']) ? $profile_data['id'] : ID));
	ob_end_flush();
	}
}


?>