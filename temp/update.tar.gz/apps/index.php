<?php $pageTitle = "I Live to Serve";

/*
put code here
*/

//$errorHandler .= "<pre>I am testing error reporting. There is nothing wrong.</pre>\n";
//always use (dot)equals to indicate that you are adding on to the error handler. Otherwise you wont be able 
//to see Debug Console results. Call ?debug on any page to see the console.
//$errorHandler .= "<pre>Here is another error on page $pageTitle.</pre>\n";

?>	