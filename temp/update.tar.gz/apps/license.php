<?php $pageTitle = "Licensing";
/*put code here*/
?>