		<?php

$pageTitle = "Streaming Music on $title";

?>	