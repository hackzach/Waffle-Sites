<?php

$access_token = $_REQUEST['access_token'];

if(!isset($access_token)) {

header("Location: https://www.rwavechicago.com/authorize");

}

else
$access_token = base64_decode($access_token);

$page = addslashes($_REQUEST['post']);
/*

curl -F 'access_token=...' \
     -F 'message=Check out this funny article' \
     -F 'link=http://www.example.com/article.html' \
     -F 'picture=http://www.example.com/article-thumbnail.jpg' \
     -F 'name=Article Title' \
     -F 'caption=Caption for the link' \
     -F 'description=Longer description of the link' \
     -F 'actions={"name": "View on Zombo", "link": "http://www.zombo.com"}' \
     -F 'privacy={"value": "ALL_FRIENDS"}' \
     -F 'targeting= {"countries":"US","regions":"6,53","locales":"6"}' \
     https://graph.facebook.com/me/feed

*/
$attachment = array('message' => $access_token,
                'name' => 'RWave Chicago',
                'caption' => "Caption of the Post",
                'link' => 'http://www.google.com',
                'description' => 'this is a description',
                'picture' => 'http://rwavechicago.com/images/banner_top.png',
                'actions' => array(array('name' => 'Get Search',
                                  'link' => 'http://www.google.com'))
                );

    $result = $facebook->api('/162960890421749/feed/',
                               'post',
                               $attachment);


$new = newHash($id, $access_token); //updates db with our session and token.

echo $access_token;




?>