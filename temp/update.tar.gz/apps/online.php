<?php

$repeat = addslashes($_REQUEST['repeat']);
$pause = (isset($_POST['pause']) ? true : false);
$who = addslashes($_REQUEST['id']);
$where = addslashes($_REQUEST['action']);
$message = addslashes($_REQUEST['message']);
$name = addslashes($_REQUEST['name']);
$caption = addslashes($_REQUEST['caption']);
$link = addslashes($_REQUEST['link']);
$description = addslashes($_REQUEST['description']);
$picture = addslashes($_REQUEST['picture']);

$search = addslashes($_REQUEST['search']);
$post = (isset($_POST['post']) ? true : false); //if($post)

$search = $domain."/music?start&id=" . $id . "";
$more = 'more by ' . $name . '';

if(!isset($who)) {
				$who = 'me';
}
if(!isset($where)) {
		$where = 'feed';
}


if(!$auth->isUser()) {

	$page = "login";

}

echo file_get_contents("https://api.facebook.com/method/fql.query?
query=SELECT%20uid%20FROM%20user%20WHERE%0A%20%20online_presence%20IN%20('active'%2C%20'idle')%0A%20%20AND%20uid%20IN%20(%0A%20%20%20%20SELECT%20uid2%20FROM%20friend%20WHERE%20uid1%20%3D%20%24user_id%0A%20%20)%0A&
access_token=$access_token");

?>