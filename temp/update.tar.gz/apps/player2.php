<?php $pageTitle = "A Tribe Called Quest";
/*put code here*/
?>