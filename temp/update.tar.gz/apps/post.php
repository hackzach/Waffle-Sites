<?php

$pageTitle = "Share on Facebook";


if(!$auth->isUser()) {

	$page = "login";

}

?>
