		<?php $pageTitle = "Private User";
/*put code here*/
?>	