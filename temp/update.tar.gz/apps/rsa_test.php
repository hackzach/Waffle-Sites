<?php

include "$site_path/modules/rsa.php";

 $text = "Peter Piper picked a peck of pickled peppers";
 $RSA = new RSA_Handler();
 $keys = $RSA->generate_keypair(1024);
 $encrypted = $RSA->encrypt($text, $keys[0]);
 $decrypted = $RSA->decrypt($encrypted, $keys[1]);
 echo $decrypted; //Will print Peter Piper picked a peck of pickled peppers


?>
