		<?php $pageTitle = "Test Page Title";
/*put code here*/
?>	