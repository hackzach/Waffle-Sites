<?php

$scope = "read_stream,publish_stream";

$authorize = $_REQUEST['code'];
$access_token = $_COOKIE["fbs_$app_id"];

	if(isset($access_token) && $access_token != "") {
		
		//trim token so that facebook understand it
		$access_token = substr($access_token, 1, (strlen($access_token)-2) );
		$array = explode("&", $access_token);
		$access_token = $array[0];
	}

	if(isset($authorize)) {
	
	 		$oauth = "https://graph.facebook.com/oauth/access_token?".						"client_id=$app_id&".
				"redirect_uri=$domain%2Fhome&".
				"client_secret=$secret&".
				"code=$authorize";

		//get access token
		$access_token = file_get_contents($oauth);

	}
	else if($get_token) {
		header("Location: $domain/authorize");
	}
?>