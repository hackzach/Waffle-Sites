<?php

		
		$file = "$dynamic/pages/$page.html";
		if(file_exists($file) !== false) {
		
			eval(" ?>".file_get_contents($file)."<?php ");
		
		}
?>