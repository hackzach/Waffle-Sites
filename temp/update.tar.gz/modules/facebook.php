<?php

$scope = "read_stream,publish_stream";

$authorize = $_GET['code'];

	if(isset($authorize)) {
	
	 		$oauth = "https://graph.facebook.com/oauth/access_token?".
				"client_id=177894922232847&".
				"redirect_uri=$domain/$page&".
				"client_secret=6e987ae3f1172c066b7f67f631c5e01c&".
				"code=$authorize";

		//get access token
		define("ACCESS_TOKEN", file_get_contents($oauth));

	}
	else {
		header("Location: $domain/authorize?ref=$page");
	}
?>