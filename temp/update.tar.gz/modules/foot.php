<?php

mysql_close();

?>