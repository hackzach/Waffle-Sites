<?php

if($id != $app_id) {

		$result = q("SELECT * FROM users WHERE id='".$id."'");
		if(!dbcount($result)) {
			$result = q("INSERT INTO users (
						name,
						id,
						password,
						email,
						hide_email,
						location,
						birthdate,
						aim,
						theme_bgcolor,
						theme_fontcolor,
						profile,
						website,
						profile_pic,
						lastvisit,
						ip,
						friends,
						whitelist,
						level,
						status) 

					VALUES(
						'',
						'" . $id . "',
						'',
						'',
						'1',
						'',
						'',
						'',
						'',
						'',
						'',
						'',
						'',
						'" . time() . "',
						'" . $_SERVER['REMOTE_ADDR'] . "',
						'',
						'',
						'1',
						'')
						");
						
						if($result == 0) {
							echo "Failure on my part. Please Try Again\n<br />";
						}
						else {

							echo "Welcome to RWave. Please wait while we redirect you...\n<br />";
						}

		}
			echo "<script>window.location='home'</script />";
	}	

?>