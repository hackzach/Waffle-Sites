<?php

$pageContent = file_get_contents($file);

eval(" ?>".$pageContent."<?php ");

?>