<?php

$errorHandler = NULL; //No Errors yet :D

$page = (isset($_REQUEST['page']) ? 
//any page requests?
(substr($_REQUEST['page'], strlen($_REQUEST['page'])-1, strlen($_REQUEST['page'])) == "/" ? 
//do they want index?
 addslashes(strip_tags($_REQUEST['page']))."index" : addslashes(strip_tags($_REQUEST['page']))) : "index"); 
//Take them where they want to go(index of folder, specific page, or homepage)

$debug = (isset($_GET['debug']) ? true : false); //triggers debugging when a page has ?debug at the end
$you = (isset($_GET['id']) ? addslashes($_GET['id']) : NULL); //gets a users id(not the current logged in user)
$ui = (isset($_GET['ui']) ? true : false); //allows pages to be shown sans templates

include SITE_PATH."/modules/auth.php"; //AUTH 

	/* hiearchy of user permissions
					if(!$auth->isSuper()) { //is not super
						if(!$auth->isAdmin()) { //is not admin
							if(!$auth->isArtist()) { //is not artist
								if(!$auth->isUser()) { //is not logged in
									$pageTitle = "Please Login.";
									$page = "login"; //redirect login; not public
									//is public
									//do public stuff here
								}
								else $page = "block"; //redirect unauthorized; not admin
								//is user
								//do user stuff here
							}
							else $page = "block"; //redirect unauthorized; not super
							//is artist
							//do artist stuff here
							
						}
						else $page = "block"; //redirect unauthorized; not super
						 //is admin
						 //do admin stuff here
					}
					else {
						//is super
						//do super stuff here
					}

		$auth->isPrivate($id); //return true if a profile is private. 

	*/

//create new objects
$auth = new auth;
$file = new file;
$site = new site;
$dir  = new dir;

//update last visit
$query->update("users", "lastvisit='" . time() . "'", "WHERE id='".ID."'");

	//-Get user data into an array-
		$user = $query->select("users", "*", "WHERE id='".ID."'", $debug);
	//--------------------------------


	//-Variable defines for profile info-

	$bgcolor = $user['theme_bgcolor'];
	$font = $user['theme_font'];
	$fontcolor = $user['theme_fontcolor'];
	$fontsize = $user['theme_fontsize'];
	$status = $user['status'];
?>