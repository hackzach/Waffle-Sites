<?php

	if (file_exists("$site_path/apps/$page.php")) {
		require_once "$site_path/apps/$page.php";
		if($debug) $app = "$page.php";
	}

	else if (file_exists("$site_path/pages/$page.html") === false) $page = "404";
		
		$file = "$site_path/pages/$page.html";

		if(file_exists($file) !== false) {
		
			
			if(!$ui) {		
				require_once "$site_path/main/header.html";
				
				$Templatefile = "$site_path/main/template.html";
			$template = parse("<%TOP_NAV%>:<%LOGIN%>:<%PAGE%>:<%SIDE_NAV%>:<%FOOT%>:<%APP_ID%>:<%DOMAIN%>:<%TITLE%>:<%ADS_TOP%>:<%ADS_BOTTOM%>:<%ADS_LEFT%>:<%ADS_RIGHT%>",
							"<?php nav(\$site_path, \$id); ?>:<?php login(\$site_path, \$domain, \$app_id, \$login);  ?>:<?php eval(\" ?>\".page(\$file).\"<?php \"); ?>:<?php admin(\$site_path, \$id); ?>:<?php foot(\$site_path); ?>:<?php print(\$app_id); ?>:<?php print \$domain; ?>:<?php print \$title; ?>:<?php ads_top(\$site_path, \$domain); ?>:<?php ads_bottom(\$site_path, \$domain); ?>:<?php ads_left(\$site_path, \$domain); ?>:<?php ads_right(\$site_path, \$domain); ?>",
							file_get_contents($Templatefile));
							
				eval(" ?>".$template."<?php ");
			}
			else {
				eval(" ?>".page($file)."<?php "); 
			}
		
		}
?>