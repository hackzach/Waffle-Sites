<?php
$version_file = SITE_PATH."/version.txt";

define("CURRENT_VERSION", $file->read($version_file));

//$latest = $file->stream("$get_software_update/version.txt");
$latest = "2.4";
if(floatval(CURRENT_VERSION) < floatval($latest)) {

$uptodate = true;

}
else $uptodate = false;


/* I don't trust these to save my life...so I'm borrowing from Stackoverflow until I can make it usable
function copy_update($site_path, $dir, $folder="") {
	$x = scandir($dir);
		for($i = 0;$i < count($x); $i++) {
			if($x[$i] != "." && $x[$i] != "..") {
				if(is_dir("$dir/$x[$i]")) {
					copy_update(SITE_PATH, "$dir/$x[$i]", "/$x[$i]");
				}
				else {
					if(copy("$dir/$x[$i]", SITE_PATH."$folder/$x[$i]") === FALSE)
					print "<p>
								-- copy ".SITE_PATH."$folder/$x[$i]\"...<span style=\"color:red\"><b>Failed.</b></span>
							</p><br>\n";
					else print "<p>
								-- copy ".SITE_PATH."$folder/$x[$i]\"...<span style=\"color:green\"><b>Done.</b></span>
								</p><br>\n";
				}
			}
		}
}	

function rm_update($dir, $folder="") {
	$x = scandir($dir);
		for($i = 0;$i < count($x); $i++) {
			if($x[$i] != "." && $x[$i] != "..") {
				if(is_dir("$dir/$x[$i]")) {
					rm_update("$dir/$x[$i]", "$x[$i]");
				}
				else {
					if(unlink("$dir/$x[$i]") === FALSE)
					print "<p>
								 -- delete \"$dir/$x[$i]\"...<span style=\"color:red\"><b>Failed.</b></span>
							</p><br>\n";
					else print "<p>
								 -- delete \"$dir/$x[$i]\"...<span style=\"color:green\"><b>Done.</b></span>
								</p><br>\n";
				}
			}
		}
}	
*/

class update {
static public function copyr($source, $dest)
{
    // recursive function to copy
    // all subdirectories and contents:
    if(is_dir($source)) {
        $dir_handle=opendir($source);
        $sourcefolder = basename($source);
        mkdir($dest."/".$sourcefolder);
        while($file=readdir($dir_handle)){
            if($file!="." && $file!=".."){
                if(is_dir($source."/".$file)){
                    self::copyr($source."/".$file, $dest."/".$sourcefolder);
                } else {
                    	if(!copy($source."/".$file, $dest."/".$file))
				print "<p>
								-- copy /".$file."...<span style=\"color:red\"><b>Failed.</b></span>
							</p><br>\n";
			else print "<p>
								-- copy /".$file."...<span style=\"color:green\"><b>Done.</b></span>
								</p><br>\n";
			}
                }
            }
        }
        closedir($dir_handle);
    } else {
        // can also handle simple copy commands
        copy($source, $dest);
    }
}


private static function deleter($dir) { 
    if (!is_dir($dir) || is_link($dir)) return unlink($dir); 
        foreach (scandir($dir) as $file) { 
            if ($file == '.' || $item == '..') continue; 
            if (!destroy_dir($dir.DS.$file)) { 
                chmod($dir.DS.$file, 0777); 
                if (!destroy_dir($dir.DS.$file)) return false; 
            }; 
        } 
        return rmdir($dir); 
    }

}
?>